# Hangman-android-studio-project
This is a basic hangman game. 
You can run it in your android studio.
To do so, you just have to import this project to your android studio.
